
char *glob2regex(char *glob);